from flask import render_template, Blueprint, request
from application.util import view_as_guest, verify_login
from application.secret import flag

web = Blueprint('web', __name__)
api = Blueprint('api', __name__)


@web.before_request
@view_as_guest
def before_request():
    pass


@web.route('/auth', methods=['POST', 'GET'])
def auth():
    if request.method == 'POST':
        return render_template('auth.html', response='Wrong Certification ID')
    else:
        return render_template('auth.html')


@web.route('/')
def index():
    return render_template('index.html')


@web.route('/order/', methods=['POST'])
@verify_login
def order():
    return render_template('order.html', flag=flag)
