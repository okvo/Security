from base64 import b64decode, b64encode
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from urllib.parse import parse_qs
from os import urandom
from datetime import datetime, timedelta

BLOCK_SIZE = AES.block_size
KEY = urandom(BLOCK_SIZE)


class session:

    @staticmethod
    def create(username, certified='True'):
        if username == 'guest':
            certified = 'False'
            expires_at = str(datetime.today() + timedelta(days=1))

        hashing_input = f'certified={certified}&user={username}&expiry={expires_at}'.encode(
        )
        crypto_segment = signature.create(KEY, hashing_input)

        return f'{signature.encode(hashing_input)}.{crypto_segment}'

    @staticmethod
    def validate_login(payload):
        hashing_input, crypto_segment = payload.split('.')

        if signature.integrity(hashing_input, crypto_segment) == False:
            return False

        data = {
            k: v[-1]
            for k, v in parse_qs(
                signature.decode(hashing_input).decode('utf-8',
                                                       'ignore')).items()
        }
        if data.get('certified', '') == 'True':
            return True
        return False


class signature:

    @staticmethod
    def encode(data):
        if type(data) is str:
            return b64encode(data.encode()).decode()
        return b64encode(data).decode()

    @staticmethod
    def decode(data):
        if type(data) is str:
            return b64decode(data.encode())
        return b64decode(data)

    @staticmethod
    def create(secret, hashing_input, iv=urandom(BLOCK_SIZE)):
        cipher = AES.new(secret, AES.MODE_CBC, iv)

        if len(hashing_input) % BLOCK_SIZE != 0:
            hashing_input = pad(hashing_input, BLOCK_SIZE)

        encrypted = cipher.encrypt(hashing_input)
        return signature.encode(iv + encrypted)

    @staticmethod
    def integrity(hashing_input, crypto_segment):
        if signature.create(KEY, signature.decode(hashing_input),
                            signature.decode(crypto_segment)
                            [:AES.block_size]) == crypto_segment:
            return True
        return False
