from flask import request, make_response, redirect, url_for
from application.models import session
import functools


def view_as_guest(func):

    @functools.wraps(func)
    def wrapped(*args, **kwargs):
        if 'buyer_info' not in request.cookies:
            resp = make_response(redirect(request.path))
            resp.set_cookie('buyer_info', session.create('guest'))
            return resp

        return func(*args, **kwargs)

    return wrapped


def verify_login(func):

    @functools.wraps(func)
    def wrapped(*args, **kwargs):

        if session.validate_login(request.cookies.get('buyer_info',
                                                      '')) == False:
            return redirect(url_for('web.auth'))

        return func(*args, **kwargs)

    return wrapped
