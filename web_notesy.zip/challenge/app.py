from flask import Flask, request, render_template, redirect, url_for
from urllib.parse import unquote
import re
import uuid
from bot import bot_runner

app = Flask(__name__)

notes = {}

def is_safe_content(content):
    decoded_content = unquote(content)
    
    if re.search(r'[\'"`]', decoded_content, re.IGNORECASE):
        return False
    return True

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        
        if is_safe_content(content):
            note_id = str(uuid.uuid4())
            note_url = url_for('view_note', note_id=note_id)
            notes[note_id] = {'title': title, 'content': content, 'url': note_url}
            return redirect(note_url)
        else:
            return "Invalid content detected. Note not created.", 400

    return render_template('create_note.html')

@app.route('/note/<note_id>', methods=['GET'])
def view_note(note_id):
    note = notes.get(note_id)
    if note:
        return render_template('view_note.html', note=note)
    return "Note not found.", 404

@app.route('/report', methods=['GET', 'POST'])
def report():
    if request.method == 'POST':
        report_url = request.form['report_url']
        bot_runner(report_url)
        return "Report submitted successfully.", 200

    return render_template('report.html')


if __name__ == '__main__':
    app.run(port=1337,host='0.0.0.0')
