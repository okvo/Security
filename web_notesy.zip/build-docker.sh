#!/bin/bash
docker rm -f web_notesy
docker build -t web_notesy .
docker run --name=web_notesy --rm -p1337:1337 -it web_notesy
